 :                                                                       :
 |-----------------------------------------------------------------------|
 | Akronyme Analogiker - We try to fail better! ........................ |
 |-----------------------------------------------------------------------|
 |                               VDC-IHFLI                               | 
 |-----------------------------------------------------------------------|
 | Release for Commodore 128 with 64K VDC RAM and Commodore 1901 Monitor |
 |-----------------------------------------------------------------------|
 :                                                                       :  
 
 PRODUCT NAME : ................................. .............. VDC-IHFLI
 GROUP        : ...................................... Akronyme Analogiker
 PLATFORM     :  Commodore 128 with 64K VDC RAM and Commodore 1901 Monitor
 RELEASE DATE : ............................................... 12/06/2011
  
 CODE         : .............................................. Tokra, Mike
 
 :                                                                       :
 |-----------------------------------------------------------------------|
 :                                                                       :
 
 SUCCESSFULLY TESTED ON:

 ............... Commodore 128 with 64K VDC RAM and Commodore 1901 Monitor
  
 :                                                                       :
 |-----------------------------------------------------------------------|
 :                                                                       :
 
 THANKS TO    : ..................................................... Mike
                                    (for his brilliant graphics converter)
                 
 |-----------------------------------------------------------------------|
 :                      Technical documentation                          :
 |-----------------------------------------------------------------------|


 Another new graphics-mode for the Commodore 128 with 64KB VDC RAM:
 
 - 640x480 pixels with 8x2 color-blocks (Interlace Half Fli)
 - 14 pictures each with own .d64
 - converter for .ppm-files included
 - works on Commodore 1901 Monitor - need feedback on other monitors
 - will *NOT* work in VICE (tested with Version 2.3) due to incomplete
   VDC-emulation

 The .d64-files are bootable. Just copy to a real disk or mount in your
 favorite SD-device and type "BOOT". This will start the viewer.
 
 Also included is a converter for the PC (ivdc_quant.exe) done by Mike.
 It's a command line tool that expect a file called "input.ppm" in Portable
 Pixmap format with resolution 640x480. Make sure to save with binary
 encoding. The converter will produce a "result.ppm"-file to check the file
 on the PC and two more files that can be loaded on the C128. Use
 "vdc-ihfli-view" to display these.

 Background:
 -----------
 This mode was created while doing the VDC-FLI-mode. It only uses the
 VDC-registers and no special software tricks. It involved a lot of trial
 and error to get the register setting just right so that both bitmaps
 and attribute-areas would align in memory as well as on screen. It's
 probably interesting to know that two 640x240 pictures with 8x2 color
 blocks are are interlaced. This means the color block themselves are also
 interlaced which can lead to some nice mixed colors.
 
 Tokra, signing off, June, 12th 2011...

 Contact: tokra@tokra.de
 :                                                                       :
 |-----------------------------------------------------------------------|
 | Akronyme Analogiker - We try to fail better! ........................ |
 |-----------------------------------------------------------------------|
 |                                VDC-FLI                                | 
 |-----------------------------------------------------------------------|
 | Release for Commodore 128 with 64K VDC RAM and Commodore 1901 Monitor |
 |-----------------------------------------------------------------------|
 :                                                                       :  
 
 PRODUCT NAME : ................................. ................ VDC-FLI
 GROUP        : ...................................... Akronyme Analogiker
 PLATFORM     :  Commodore 128 with 64K VDC RAM and Commodore 1901 Monitor
 RELEASE DATE : ............................................... 12/06/2011
  
 CODE         : .............................................. Tokra, Mike
 
 :                                                                       :
 |-----------------------------------------------------------------------|
 :                                                                       :
 
 SUCCESSFULLY TESTED ON:

 ............... Commodore 128 with 64K VDC RAM and Commodore 1901 Monitor
  
 :                                                                       :
 |-----------------------------------------------------------------------|
 :                                                                       :
 
 THANKS TO    : ..................................................... Mike
                                    (for his brilliant graphics converter)
                 
                .............................................. Hydrophilic
                            (for the copy to VDC-RAM and keypress-routine)
                                                        
 |-----------------------------------------------------------------------|
 :                      Technical documentation                          :
 |-----------------------------------------------------------------------|


 A new graphics-mode for the Commodore 128 with 64KB VDC RAM:
 
 - 480x252 pixels with 8x1 color-blocks - slideshow of 5 pictures
 - converter for .ppm-files included
 - works on Commodore 1901 Monitor - need feedback on other monitors
 - will *NOT* work in VICE (tested with Version 2.3) due to incomplete
   VDC-emulation

 The .d64 is bootable. Just copy to a real disk or mount in your favorite
 SD-device and type "BOOT". This will start the slideshow. You can go
 to the next picture with the spacebar. During loading the VDC-screen
 will be garbled. That's fine. Only once fully loaded it will display the
 picture. Read "Background" below to find out why.
 
 Also included is a converter for the PC (vdc_quant.exe) done by Mike.
 It's a command line tool that expect a file called "input.ppm" in Portable
 Pixmap format with resolution 480x252. Make sure to save with binary
 encoding. Also since pixels are twice as high on the C128 VDC mode choose
 an image that looks good at 480x504 on the PC and downscale it to 480x252.
 This will look squeezed on your PC but will look fine on the C128. The
 converter will produce a "result.ppm"-file to check the file on the PC and
 two more files that can be loaded on the C128. Use "vdc-fliew-basic" to
 display these.

 Background:
 -----------
 This mode came about trying to figure out how the (brilliant) "Risen from
 Oblivion"-demo does its own FLI-mode. By hardware the VDC only supports a
 maximum of 8x2 color-blocks by setting register 9 of the VDC to two
 rasterlines. If you try to set it to 1 rasterline to get an 8x1 mode the
 VDC won't activate the display and you only get a blank screen.  The
 trick to force the VDC to display is to watch bit 5 of $d600 (VBLANK) and
 switch register 9 to one rasterline right after the VLANK-period has
 finished and back to any other value once VBLANK starts again. This fools
 the VDC into displaying the 8x1 mode. However since the VDC now has to
 fetch the character- as well as the attribut-byte for every rasterline
 you can only address a screen of 60 chars wide (=480 pixels), otherwise
 the screen gets garbled. The register 9-switcher is realized as a quick
 and dirty 47 byte assembler routine. If you want to do it proper you will
 have to set up a VDC-raster-interrupt and for that you first need to
 measure your specific VDC-chip's speed. That is what "Risen from Oblivion"
 does when you start it.

 
 Tokra, signing off, June, 12th 2011...

 Contact: tokra@tokra.de
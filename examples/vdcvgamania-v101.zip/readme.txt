 :                                                                       :
 |-----------------------------------------------------------------------|
 | Akronyme Analogiker - We try to fail better! ........................ |
 |-----------------------------------------------------------------------|
 |                             VDC VGA Mania                             | 
 |-----------------------------------------------------------------------|
 :                                                                       :  
 
 PRODUCT NAME : ............................................ VDC VGA Mania
 GROUP        : ...................................... Akronyme Analogiker
 PLATFORM     : ..... Commodore 128 (64K VDC-RAM needed for graphic modes)
 RELEASE DATE : ........................................... Sep, 21nd 2013
  
 CODE         : .............................................. Tokra, Mike

 :                                                                       :
 |-----------------------------------------------------------------------|
 :                                                                       :
 
 SUCCESSFULLY TESTED ON:

 .......................................... C128 with 64K expanded VDC-RAM
 ........................................ Richard42's RGBI->RGBA converter
 ................................... simple 9-pin RGBI to 15-pin VGA cable
 .............................................. two different VGA-monitors


 DESCRIPTION:

 A small presentation of how the VDC-chip can be put in a VGA-compatible
 mode of nearly 31.5kHz and 60Hz:
 
 - adjustable text-mode (up to 50 chars in full color)
 - slideshows of possible graphic modes:
 -- 320x480 8x2 color resolution
 -- 360x480 8x3 color resolution
 -- 400x480 monochrome

 Converters and sources are included.
 

 INSTRUCTIONS:

 Just run "vdc vga mania" to start. You will be asked to connect a
 VGA-monitor to the RGB-out of your C128. The VDC will then go into a
 50x25 text-mode that you can adjust to your needs and likes. Because of
 the higher horizontal frequency about 50 chars is the maximum width
 that's possible to display. If you try to higher the VDC will not keep up
 and the screen will look garbled. You can squeeze out a few more chars if
 you go to monochrome mode, but I found 50 to be the highest stable and
 sensible text-resolution.
 
 The slideshows will show two pictures each, the first one being the same
 for each mode, so you can compare quality between the different
 resolutions. The higher the color resolution is, the less width is
 possibe again because of the VDC needing to keep up with the display. You
 can adjust the picture position with the cursor keys.
 
 The converters for the color graphics work on the PC and expect a .ppm
 (Portable Pixel Map)-file to convert in exactly the right resolution
 named 'input.ppm' - it then produces some files which can be read by the
 appropriate -view BASIC-application on the C128.
 
 The converter for the monochrome 400x480 mode is a simple BASIC-program
 which expects a .pgm (Portable Graymap)-file. I suggest using this one
 in VICE and warp-mode.


 TECHNICAL INFO:
 
 The idea for this small demo came out of a discussion on the
 commodore128.org-forum about connecting the C128 to a VGA-monitor in the
 80-column mode which the VDC chip produces:
 
 http://www.commodore128.org/index.php?topic=3877
 
 The C128 in 80-column-mode puts out a signal that is pretty much like the
 old CGA of early IBM PCs. You have a horizontal frequency of about
 15.7kHz and a vertical frequency of 60Hz for NTSC and 50Hz for PAL making
 it possible to display such a signal on a TV relatively easily as well.
 
 Also, the signal is digital (RGBI). You have 8 colors with (RGB) with
 intensity (I) either turned on or off for a total of 16 colors.
 
 Now, VGA has horizontal frequency of 31.5 kHz (roughly twice as much as
 the C128) and colors are analog RGB. To be able to display a C128's
 signal on VGA you need to double the horizontal frequency as well as
 convert the 16 digital colors to analog values.
 
 The frequency doubling is usually done by a line-doubler like the
 GBS-8220. This uses digital signal processing to create a completely new
 picture out of the data it receives.
 
 The color-conversion from digital RGBI to analog RGB can be done in
 several ways. The easiest solution is to just connect the R, G and B
 like with this cable:
 
 http://www.ambery.com/db9todbadca.html
 
 You get only 8 out of 16 colors this way and the signal levels will be
 way to high (RGBI uses 5V-levels, while VGA uses 0.7V). While this works
 for a first test this is obviously not the desired solution.
 
 An easy and cheap enough solution is a small resistor-network of which
 several layouts can be found around the internet. A very good explanation
 can be found at Hydrophilic's site:
 
 https://sites.google.com/site/h2obsession/CBM/C128/rgbi-to-vga
 
 This way you get 16 colors, although you get the color dark-yellow
 instead of brown. The color brown is a special case, you can read about
 that in Wikipedia:
 
 http://en.wikipedia.org/wiki/Color_Graphics_Adapter#With_an_RGBI_monitor
 
 The most elegant RGBI->RGBA conversion I have seen yet was provided by
 Richard42 in the commodore128.org-forum. This also includes a fix for the
 color brown. Read more about this in the forum-thread mentioned at the
 start.
 
 Now, to get back to what this program actually does: It alleviates the
 need for the digital signal-processing or line doubler (for which you
 would need the GBS-8220) by putting the VDC into a mode of nearly 31.5kHz
 and 60Hz which VGA-monitors will recognize. While you still need the
 conversion of the color from digital to analog, the VDC-chip will
 actually provide the signal that is displayed on the VGA-monitor.
 

 :                                                                       :
 |-----------------------------------------------------------------------|
 :                                                                       :
 
 SPECIAL THANKS TO : ................................................ Mike
                           (for his brilliant as ever graphics converters)
 
 MORE THANKS TO : ................................. Richard42, Hydrophilic
 
 GREETINGS TO:
 
 The members of the Commodore128.org-forum

 Tokra, signing off, Sep, 21st 2013...

 Contact: tokra@tokra.de
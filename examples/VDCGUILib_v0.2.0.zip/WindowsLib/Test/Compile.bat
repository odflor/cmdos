SETLOCAL ENABLEDELAYEDEXPANSION

set MODE="c128"
set OBJECT="E:\cc65\lib\c128.o"
set LIBRARY="E:\cc65\lib\c128.lib"

set COMPILER="E:\cc65\bin\cc65"
set ASSEMBLER="E:\cc65\bin\ca65"
set LINKER="E:\cc65\bin\ld65"

REM: Compile each .C file into assembler.
for /f %%a IN ('dir /b *.c') do %COMPILER% -g -O -I E:\cc65\include -t %MODE% %%a -o .\Debug\%%~na.s

REM: Assemble each .S file an object file.
for /f %%a IN ('dir /b .\Debug\*.s') do %ASSEMBLER% .\Debug\%%a
for /f %%a IN ('dir /b *.s') do %ASSEMBLER% -t %MODE% %%a -o .\Debug\%%~na.o

REM: Link all the .O files together
set FILES=
for /f %%a IN ('dir /b .\Debug\*.o') do set FILES=!FILES! .\Debug\%%a
%LINKER% -t %MODE% -Ln .\Debug\output.lbl -m .\Debug\output.map -o .\Debug\output %OBJECT% %FILES% %LIBRARY%